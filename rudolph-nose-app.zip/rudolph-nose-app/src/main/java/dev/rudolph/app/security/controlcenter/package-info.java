@NullMarked
package dev.rudolph.app.security.controlcenter;

import org.jspecify.annotations.NullMarked;
