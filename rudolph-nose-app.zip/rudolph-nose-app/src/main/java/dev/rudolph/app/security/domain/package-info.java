@NullMarked
package dev.rudolph.app.security.domain;

import org.jspecify.annotations.NullMarked;
