/**
 * This package contains reusable domain classes.
 */
@NullMarked
package dev.rudolph.app.base.domain;

import org.jspecify.annotations.NullMarked;
